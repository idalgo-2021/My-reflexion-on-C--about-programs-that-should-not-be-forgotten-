#ifndef EXPRESSION_PARSER_H
#define EXPRESSION_PARSER_H

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Типы лексем (токенов)
typedef enum {
    OPERATOR,    // 0   Операторы: +, -, *, /
    FUNCTION,    // 1   Функции: sin, cos, tg, ctg, sqrt, ln
    CONSTANT,    // 2   Константы: числовые значения
    VARIABLE,    // 3   Переменные: x, y, ...
    LEFT_PAREN,  // 4   Левая скобка '('
    RIGHT_PAREN  // 5   Правая скобка ')'
} TokenType;

// Структура лексемы (токена)
typedef struct {
    TokenType type;
    char* lexeme;
} Token;

// Объявление функции для разбора выражения и получения списка лексем
Token* parse_expression(const char* expr, int* token_count);

// Объявление функции для определения приоритета операторов
int get_operator_precedence(char operator);

// Объявление вспомогательных функций для проверки символов
int is_operator(char c);
int is_whitespace(char c);
int is_digit(char c);
int is_alpha(char c);
int is_alnum(char c);

#endif  // EXPRESSION_PARSER_H
