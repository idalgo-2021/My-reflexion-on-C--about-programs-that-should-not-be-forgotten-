
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "expression_parser.h"
#include "rpn.h"

#define WIDTH 80
#define HEIGHT 25
#define PI 3.14159265358979323846

void background_fill(char graph[][WIDTH]);
void print_graph(char graph[][WIDTH]);
char* tokens_to_rpn_string(Token* tokens, int token_count);
void plot_expression(const char* expression);
void compute_and_draw_graph(char graph[][WIDTH], Token* rpn_tokens, int rpn_token_count, int* fl_err);

// Получение массива токенов из строки
char* tokens_to_rpn_string(Token* tokens, int token_count) {
    size_t buffer_size = 256;
    char* rpn_str = (char*)malloc(buffer_size * sizeof(char));
    rpn_str[0] = '\0';  // Инициализация пустой строкой

    for (int i = 0; i < token_count; ++i) {
        strcat(rpn_str, tokens[i].lexeme);
        if (i < token_count - 1) {
            strcat(rpn_str, " ");
        }

        // Увеличиваем размер буфера при необходимости
        if (strlen(rpn_str) + strlen(tokens[i].lexeme) + 2 > buffer_size) {
            buffer_size *= 2;
            rpn_str = (char*)realloc(rpn_str, buffer_size * sizeof(char));
        }
    }
    return rpn_str;
}

// Построение графика по выражению
void plot_expression(const char* expression) {
    system("clear");
    printf("Expression: %s\n", expression);

    char graph[HEIGHT][WIDTH];

    int token_count;
    Token* tokens = parse_expression(expression, &token_count);

    if (tokens == NULL) {
        printf("Error: Failed to parse expression.\n");
        return;
    }
    // Проверка на допустимость типов токенов
    for (int i = 0; i < token_count; ++i) {
        Token token = tokens[i];
        if (token.type != CONSTANT && token.type != VARIABLE && token.type != OPERATOR &&
            token.type != FUNCTION && token.type != LEFT_PAREN && token.type != RIGHT_PAREN) {
            printf("Error: Invalid token type encountered: %s\n", token.lexeme);
            free(tokens);
            return;
        }
    }

    int rpn_token_count;
    Token* rpn_tokens = shunting_yard(tokens, token_count, &rpn_token_count);
    if (rpn_tokens == NULL) {
        printf("Error: Failed to convert to RPN.\n");
        free(tokens);
        return;
    }

    char* rpn_str = tokens_to_rpn_string(rpn_tokens, rpn_token_count);
    printf("RPN: %s\n", rpn_str);
    free(rpn_str);

    background_fill(graph);

    int fl_err = 0;
    compute_and_draw_graph(graph, rpn_tokens, rpn_token_count, &fl_err);
    if (fl_err != 0) {
        free(tokens);
        free(rpn_tokens);
        return;
    }

    print_graph(graph);

    free(tokens);
    free(rpn_tokens);
}

// Заливка поля фоновыми символами
void background_fill(char graph[][WIDTH]) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            graph[i][j] = '.';
        }
    }
}

// Печать графика
void print_graph(char graph[][WIDTH]) {
    for (int i = 0; i < HEIGHT; i++) {
        for (int j = 0; j < WIDTH; j++) {
            printf("%c", graph[i][j]);
        }
        printf("\n");
    }
}

// Вычисление значений и их фиксация на графике
void compute_and_draw_graph(char graph[][WIDTH], Token* rpn_tokens, int rpn_token_count, int* fl_err) {
    double x, y;

    for (int col = 0; col < WIDTH; ++col) {
        x = col * (4 * PI / WIDTH);

        // Создание копии массива токенов для вычисления значения выражения
        Token* rpn_tokens_copy = (Token*)malloc(rpn_token_count * sizeof(Token));
        memcpy(rpn_tokens_copy, rpn_tokens, rpn_token_count * sizeof(Token));

        // Замена переменной x в копии токенов на текущее значение абсциссы
        for (int i = 0; i < rpn_token_count; ++i) {
            if (rpn_tokens_copy[i].type == VARIABLE) {
                sprintf(rpn_tokens_copy[i].lexeme, "%lf", x);
                rpn_tokens_copy[i].type = CONSTANT;  // Помечаем как константу
            }
        }

        // Вычисление выражения
        y = evaluate_rpn(rpn_tokens_copy, rpn_token_count, fl_err);
        if (*fl_err != 0) {
            free(rpn_tokens_copy);
            printf("Error occurred during calculation.\n");
            break;
        }
        // Проверка на NaN
        if (isnan(y)) {
            free(rpn_tokens_copy);
            printf("Error: Invalid result (NaN) received.\n");
            *fl_err = 1;
            break;
        }
        // printf("%lf %lf\n", x, y);
        // printf("%lf\n", y);
        // // Проверка на бесконечность
        // if (isinf(y)) {
        //     free(rpn_tokens_copy);
        //     printf("Error: Division by zero detected.\n");
        //     *fl_err = 1;
        //     break;
        // }

        if (!isnan(y)) {
            int row = (int)(y * (HEIGHT - 1) / 2) + 12;
            if (row >= 0 && row < HEIGHT) {
                graph[row][col] = '*';
            }
        }
        free(rpn_tokens_copy);
    }
}

int main() {
    char expression[100];

    printf("Enter the expression: ");
    scanf("%s", expression);

    plot_expression(expression);

    return 0;
}
