#include "rpn.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define M_PI 3.14159265358979323846

// Функция для выполнения преобразования в обратную польскую нотацию с использованием алгоритма сортировочной
// станции
Token* shunting_yard(Token* tokens, int token_count, int* output_count) {
    Token* output = (Token*)malloc(token_count * sizeof(Token));
    Token* stack = (Token*)malloc(token_count * sizeof(Token));
    int output_index = 0;
    int stack_index = 0;

    for (int i = 0; i < token_count; ++i) {
        Token token = tokens[i];

        // Проверяем тип токена
        if (token.type != CONSTANT && token.type != VARIABLE && token.type != OPERATOR &&
            token.type != FUNCTION && token.type != LEFT_PAREN && token.type != RIGHT_PAREN) {
            fprintf(stderr, "Error: Unknown token type encountered: %s\n", token.lexeme);
            free(output);
            free(stack);
            *output_count = 0;
            return NULL;
        }

        Token new_token;
        new_token.type = token.type;

        new_token.lexeme = strdup(token.lexeme);
        // new_token.lexeme = (char*)malloc((strlen(token.lexeme) + 1) * sizeof(char));
        // strcpy(new_token.lexeme, token.lexeme);

        if (token.type == CONSTANT || token.type == VARIABLE) {
            output[output_index++] = new_token;
        } else if (token.type == FUNCTION) {
            stack[stack_index++] = new_token;
        } else if (token.type == OPERATOR) {
            while (
                stack_index > 0 && stack[stack_index - 1].type == OPERATOR &&
                ((token.lexeme[0] != '~' && get_operator_precedence(token.lexeme[0]) <=
                                                get_operator_precedence(stack[stack_index - 1].lexeme[0])) ||
                 (token.lexeme[0] == '~' && get_operator_precedence(token.lexeme[0]) <
                                                get_operator_precedence(stack[stack_index - 1].lexeme[0])))) {
                output[output_index++] = stack[--stack_index];
            }
            stack[stack_index++] = new_token;
        } else if (token.type == LEFT_PAREN) {
            stack[stack_index++] = new_token;
        } else if (token.type == RIGHT_PAREN) {
            while (stack_index > 0 && stack[stack_index - 1].type != LEFT_PAREN) {
                output[output_index++] = stack[--stack_index];
            }
            if (stack_index == 0) {
                fprintf(stderr, "Mismatched parentheses\n");
                free(new_token.lexeme);
                free(output);
                free(stack);
                *output_count = 0;
                return NULL;
            }
            // Remove LEFT_PAREN from stack
            --stack_index;

            if (stack_index > 0 && stack[stack_index - 1].type == FUNCTION) {
                output[output_index++] = stack[--stack_index];
            }
        }
        // free(new_token.lexeme);
    }

    while (stack_index > 0) {
        if (stack[stack_index - 1].type == LEFT_PAREN) {
            fprintf(stderr, "Mismatched parentheses\n");
            free(output);
            free(stack);
            *output_count = 0;
            return NULL;
        }
        output[output_index++] = stack[--stack_index];
    }

    *output_count = output_index;
    free(stack);
    return output;
}

// Функция для оценки выражения в обратной польской нотации
double evaluate_rpn(Token* rpn_tokens, int rpn_token_count, int* fl_err) {
    double* stack = (double*)malloc(rpn_token_count * sizeof(double));
    int stack_index = 0;

    for (int i = 0; i < rpn_token_count; ++i) {
        Token token = rpn_tokens[i];

        if (token.type == CONSTANT) {
            stack[stack_index++] = atof(token.lexeme);
        } else if (token.type == VARIABLE) {
            stack[stack_index++] = 0;  // Placeholder
        } else if (token.type == OPERATOR) {
            if (stack_index < 2 && token.lexeme[0] != '~') {
                *fl_err = 1;
                fprintf(stderr, "Not enough operands for operator %s\n", token.lexeme);
                free(stack);
                return NAN;
            }

            double b = stack[--stack_index];
            double a = (token.lexeme[0] != '~') ? stack[--stack_index] : 0;

            switch (token.lexeme[0]) {
                case '+':
                    stack[stack_index++] = a + b;
                    break;
                case '-':
                    stack[stack_index++] = a - b;
                    break;
                case '*':
                    stack[stack_index++] = a * b;
                    break;
                case '/':
                    // if (b == 0) {
                    //     *fl_err = 1;
                    //     fprintf(stderr, "dDivision by zero\n");
                    //     free(stack);
                    //     return NAN;
                    // }
                    stack[stack_index++] = a / b;
                    break;
                case '~':
                    stack[stack_index++] = -b;
                    break;
                default:
                    *fl_err = 1;
                    fprintf(stderr, "Unknown operator %s\n", token.lexeme);
                    free(stack);
                    return NAN;
            }
        } else if (token.type == FUNCTION) {
            if (stack_index < 1) {
                *fl_err = 1;
                fprintf(stderr, "Not enough operands for function %s\n", token.lexeme);
                free(stack);
                return NAN;
            }

            double a = stack[--stack_index];

            if (strcmp(token.lexeme, "sin") == 0) {
                stack[stack_index++] = sin(a);
            } else if (strcmp(token.lexeme, "cos") == 0) {
                stack[stack_index++] = cos(a);
            } else if (strcmp(token.lexeme, "tg") == 0) {
                stack[stack_index++] = tan(a);
            } else if (strcmp(token.lexeme, "ctg") == 0) {
                // if (a == 0) {
                //     *fl_err = 1;
                //     fprintf(stderr, "Division by zero\n");
                //     free(stack);
                //     return NAN;
                // }
                stack[stack_index++] = 1 / tan(a);
            } else if (strcmp(token.lexeme, "sqrt") == 0) {
                // if (a < 0) {
                //     *fl_err = 1;
                //     fprintf(stderr, "Square root of negative number\n");
                //     free(stack);
                //     return NAN;
                // }
                stack[stack_index++] = sqrt(a);
            } else if (strcmp(token.lexeme, "ln") == 0) {
                // if (a <= 0) {
                //     *fl_err = 1;
                //     fprintf(stderr, "Logarithm of non-positive number\n");
                //     free(stack);
                //     return NAN;
                // }
                stack[stack_index++] = log(a);
            } else {
                *fl_err = 1;
                fprintf(stderr, "Unknown function %s\n", token.lexeme);
                free(stack);
                return NAN;
            }
        }
    }

    if (stack_index != 1) {
        *fl_err = 1;
        fprintf(stderr, "Invalid RPN expression\n");
        free(stack);
        return NAN;
    }

    double result = stack[0];
    free(stack);
    return result;
}
