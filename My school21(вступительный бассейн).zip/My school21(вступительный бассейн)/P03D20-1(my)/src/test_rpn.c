// test_rpn.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "expression_parser.h"
#include "rpn.h"

char* tokens_to_rpn_string(Token* tokens, int token_count);
void run_test(const char* expression);

// Функция для печати списка лексем в формате RPN (для отладки)
char* tokens_to_rpn_string(Token* tokens, int token_count) {
    size_t buffer_size = 256;
    char* rpn_str = (char*)malloc(buffer_size * sizeof(char));
    rpn_str[0] = '\0';  // Initialize empty string

    for (int i = 0; i < token_count; ++i) {
        strcat(rpn_str, tokens[i].lexeme);
        if (i < token_count - 1) {
            strcat(rpn_str, " ");
        }

        // Increase buffer size if needed
        if (strlen(rpn_str) + strlen(tokens[i].lexeme) + 2 > buffer_size) {
            buffer_size *= 2;
            rpn_str = (char*)realloc(rpn_str, buffer_size * sizeof(char));
        }
    }
    return rpn_str;
}

void run_test(const char* expression) {
    printf("Expression: %s\n", expression);

    int token_count;
    Token* tokens = parse_expression(expression, &token_count);

    int rpn_token_count;
    Token* rpn_tokens = shunting_yard(tokens, token_count, &rpn_token_count);
    char* rpn_str = tokens_to_rpn_string(rpn_tokens, rpn_token_count);

    int fl_err = 0;
    double result = evaluate_rpn(rpn_tokens, rpn_token_count, &fl_err);
    printf("RPN: %s\n", rpn_str);
    printf("Result: %lf\n\n", result);
    if (fl_err != 0) {
        printf("    Error in calculate of expression\n");
    }

    // Освобождение памяти
    for (int i = 0; i < token_count; i++) {
        free(tokens[i].lexeme);
    }
    free(tokens);

    for (int i = 0; i < rpn_token_count; i++) {
        // Убедимся, что токены в rpn_tokens не указывают на те же лексемы, что и в tokens
        if (rpn_tokens[i].type == CONSTANT || rpn_tokens[i].type == VARIABLE) {
            free(rpn_tokens[i].lexeme);
        }
    }
    free(rpn_tokens);
    free(rpn_str);
}

int main() {
    const char* expressions[] = {"-3",
                                 "ln(ln(650) + 200) + 33",
                                 "1 + (2+3) + (4 + 5) + (6 + 7) + 4*3/8",
                                 "sin(30)",
                                 "3*3",
                                 "tg(30)",
                                 "(2+2)*2",
                                 "1/(2-2)"};

    int num_expressions = sizeof(expressions) / sizeof(expressions[0]);

    for (int i = 0; i < num_expressions; ++i) {
        run_test(expressions[i]);
    }

    return 0;
}
