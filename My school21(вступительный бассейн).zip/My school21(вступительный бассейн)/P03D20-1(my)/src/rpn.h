#ifndef RPN_H
#define RPN_H

#include "expression_parser.h"

// Функция для преобразования выражения в обратную польскую нотацию
Token* shunting_yard(Token* tokens, int token_count, int* rpn_token_count);

// Функция для вычисления выражения в обратной польской нотации
double evaluate_rpn(Token* rpn_tokens, int rpn_token_count, int* fl_err);

#endif
