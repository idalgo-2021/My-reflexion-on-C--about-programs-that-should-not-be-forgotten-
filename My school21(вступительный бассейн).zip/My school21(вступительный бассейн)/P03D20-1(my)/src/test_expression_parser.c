#include <stdio.h>

#include "expression_parser.h"

void print_tokens(Token* tokens, int token_count);

// Функция для печати списка лексем (для отладки)
void print_tokens(Token* tokens, int token_count) {
    printf("Tokens:\n");
    for (int i = 0; i < token_count; ++i) {
        printf("[%d] Type: %d, Lexeme: %s\n", i, tokens[i].type, tokens[i].lexeme);
    }
}

int main() {
    const char* expr = "x*x+tg(x) - (sin(x) + 2*sqrt(16+11+5) * (3 - ln(ln(650)) +4))*cos(x)";

    int token_count;
    Token* tokens = parse_expression(expr, &token_count);

    if (tokens) {
        print_tokens(tokens, token_count);

        // Освобождаем выделенную память для лексем
        for (int i = 0; i < token_count; ++i) {
            free(tokens[i].lexeme);
        }
        free(tokens);
    } else {
        fprintf(stderr, "Failed to parse expression.\n");
    }

    return 0;
}
