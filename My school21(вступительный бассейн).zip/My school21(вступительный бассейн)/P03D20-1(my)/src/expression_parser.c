#include "expression_parser.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Массив строк для типов токенов
const char* token_type_strings[] = {
    "OPERATOR",    // Type: 0
    "FUNCTION",    // Type: 1
    "CONSTANT",    // Type: 2
    "VARIABLE",    // Type: 3
    "LEFT_PAREN",  // Type: 4
    "RIGHT_PAREN"  // Type: 5
};

// Вспомогательная функция для определения приоритета операторов
int get_operator_precedence(char operator) {
    switch (operator) {
        case '+':
        case '-':
            return 1;
        case '*':
        case '/':
            return 2;
        case '~':  // Унарный минус
            return 3;
        default:
            return 0;
    }
}

// Функция для проверки, является ли символ оператором
int is_operator(char c) { return (c == '+' || c == '-' || c == '*' || c == '/'); }

// Функция для проверки, является ли символ разделителем (пробелом)
int is_whitespace(char c) { return (c == ' ' || c == '\t'); }

// Функция для проверки, является ли символ цифрой
int is_digit(char c) { return (c >= '0' && c <= '9'); }

// Функция для проверки, является ли символ буквой
int is_alpha(char c) { return ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z')); }

// Функция для проверки, является ли символ буквой или цифрой
int is_alnum(char c) { return (is_alpha(c) || is_digit(c)); }

// Функция для разбора выражения и получения списка лексем
Token* parse_expression(const char* expr, int* token_count) {
    size_t length = strlen(expr);
    Token* tokens = NULL;
    size_t tokens_size = 10;
    size_t tokens_index = 0;

    tokens = (Token*)malloc(tokens_size * sizeof(Token));
    if (!tokens) {
        fprintf(stderr, "Memory allocation error\n");
        *token_count = 0;
        return NULL;
    }

    size_t i = 0;
    while (i < length) {
        // Пропускаем пробелы
        if (is_whitespace(expr[i])) {
            i++;
            continue;
        }

        // Распознавание операторов
        if (is_operator(expr[i])) {
            if (tokens_index >= tokens_size) {
                tokens_size += 10;
                tokens = realloc(tokens, tokens_size * sizeof(Token));
                if (!tokens) {
                    fprintf(stderr, "Memory reallocation error\n");
                    *token_count = 0;
                    return NULL;
                }
            }
            tokens[tokens_index].type = OPERATOR;
            tokens[tokens_index].lexeme = (char*)malloc(2 * sizeof(char));
            if (expr[i] == '-' && (i == 0 || is_operator(expr[i - 1]) || expr[i - 1] == '(')) {
                tokens[tokens_index].lexeme[0] = '~';  // Используем '~' для унарного минуса
            } else {
                tokens[tokens_index].lexeme[0] = expr[i];
            }
            tokens[tokens_index].lexeme[1] = '\0';
            tokens_index++;
            i++;
        }

        // Распознавание чисел
        else if (is_digit(expr[i])) {
            size_t start = i;
            while (is_digit(expr[i]) || expr[i] == '.') {
                i++;
            }
            size_t length = i - start;
            if (tokens_index >= tokens_size) {
                tokens_size += 10;
                tokens = realloc(tokens, tokens_size * sizeof(Token));
                if (!tokens) {
                    fprintf(stderr, "Memory reallocation error\n");
                    *token_count = 0;
                    return NULL;
                }
            }
            tokens[tokens_index].type = CONSTANT;
            tokens[tokens_index].lexeme = (char*)malloc((length + 1) * sizeof(char));
            strncpy(tokens[tokens_index].lexeme, &expr[start], length);

            tokens[tokens_index].lexeme[length] = '\0';
            tokens_index++;
        }

        // Распознавание переменных и функций
        else if (is_alpha(expr[i])) {
            size_t start = i;
            while (is_alnum(expr[i]) || expr[i] == '_') {
                i++;
            }
            size_t length = i - start;
            if (tokens_index >= tokens_size) {
                tokens_size += 10;
                tokens = realloc(tokens, tokens_size * sizeof(Token));
                if (!tokens) {
                    fprintf(stderr, "Memory reallocation error\n");
                    *token_count = 0;
                    return NULL;
                }
            }
            // Проверяем, является ли лексема функцией
            if (strncmp(&expr[start], "sin", 3) == 0 || strncmp(&expr[start], "cos", 3) == 0 ||
                strncmp(&expr[start], "tg", 2) == 0 || strncmp(&expr[start], "ctg", 3) == 0 ||
                strncmp(&expr[start], "sqrt", 4) == 0 || strncmp(&expr[start], "ln", 2) == 0) {
                tokens[tokens_index].type = FUNCTION;
            } else {
                tokens[tokens_index].type = VARIABLE;
            }
            tokens[tokens_index].lexeme = (char*)malloc((length + 1) * sizeof(char));
            strncpy(tokens[tokens_index].lexeme, &expr[start], length);
            tokens[tokens_index].lexeme[length] = '\0';
            tokens_index++;
        }

        // Распознавание скобок
        else if (expr[i] == '(') {
            if (tokens_index >= tokens_size) {
                tokens_size += 10;
                tokens = realloc(tokens, tokens_size * sizeof(Token));
                if (!tokens) {
                    fprintf(stderr, "Memory reallocation error\n");
                    *token_count = 0;
                    return NULL;
                }
            }
            tokens[tokens_index].type = LEFT_PAREN;
            tokens[tokens_index].lexeme = (char*)malloc(2 * sizeof(char));
            tokens[tokens_index].lexeme[0] = '(';
            tokens[tokens_index].lexeme[1] = '\0';
            tokens_index++;
            i++;
        } else if (expr[i] == ')') {
            if (tokens_index >= tokens_size) {
                tokens_size += 10;
                tokens = realloc(tokens, tokens_size * sizeof(Token));
                if (!tokens) {
                    fprintf(stderr, "Memory reallocation error\n");
                    *token_count = 0;
                    return NULL;
                }
            }
            tokens[tokens_index].type = RIGHT_PAREN;
            tokens[tokens_index].lexeme = (char*)malloc(2 * sizeof(char));
            tokens[tokens_index].lexeme[0] = ')';
            tokens[tokens_index].lexeme[1] = '\0';
            tokens_index++;
            i++;
        } else {
            fprintf(stderr, "Unknown character: %c\n", expr[i]);
            for (size_t j = 0; j < tokens_index; j++) {
                free(tokens[j].lexeme);
            }
            free(tokens);
            *token_count = 0;
            return NULL;
        }
    }

    *token_count = tokens_index;
    return tokens;
}
