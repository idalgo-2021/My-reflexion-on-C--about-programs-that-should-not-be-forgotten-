#include <stdio.h>

int main() {
  float x;
  float y;
  if (scanf("%f %f", &x, &y) != 2) {
    printf("You need input two float argument\n");
    printf("n/a\n");
    return 0;
  }

  if ((x * x + y * y) < 25) {
    printf("GOTCHA\n");
  } else {
    printf("MISS\n");
  }

  return 0;
}