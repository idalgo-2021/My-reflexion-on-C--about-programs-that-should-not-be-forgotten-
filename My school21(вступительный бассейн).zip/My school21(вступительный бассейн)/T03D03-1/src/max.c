#include <stdio.h>

int max(int a, int b);

int main() {
  int a, b;
  if (scanf("%d %d", &a, &b) != 2) {
    printf("You need input two integer arguments\n");
    printf("n/a\n");
    return 0;
  }
  printf("%d\n", max(a, b));

  return 0;
}

int max(int a, int b) {
  if (a > b) {
    return a;
  }
  return b;
}