#!/bin/bash

############################## HOW IT USE ##############################
# choppedj@ul-f2:~/$ cd src
# choppedj@ul-f2:~/src$ ./log_analyzer.sh <logfile>
# Example: choppedj@ul-f2:~/src$ ./log_analyzer.sh file.log
# Important - each hash-record must be longer than 6 characters
########################################################################

# Check of quantity input params
if [ $# -lt 1 ]; then
    echo "Start this script with args: $0 <logfile>"
    exit 1
fi    

LOGFILE=$1

# Check exists file
if [ ! -f $LOGFILE ]; then
    echo "Logfile: $1 not found"
    exit 1
fi

num=$(cat $LOGFILE | awk '{print $1}' | wc -l)

uniq_files=$(cat $LOGFILE | awk '{print $1}' | sort | uniq | wc -l)

# changes=$(cat $LOGFILE | awk '{print $8}' | wc -l)
changes=$(cat $LOGFILE | awk '{if (length($8)>6) {print $8}}' | wc -l)

echo "$num $uniq_files $changes"
