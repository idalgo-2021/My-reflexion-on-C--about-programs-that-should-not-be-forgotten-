#!/bin/bash

############################## HOW IT USE ##############################
# choppedj@ul-f2:~/$ cd src
# choppedj@ul-f2:~/src$ ./edit.sh <file_path> <search_string> <replace_string>
# Example: choppedj@ul-f2:~/src$ ./edit.sh history_of_vim.txt old_string new_string
########################################################################

# Check of quantity input params
if [ $# -lt 2 ]; then
    echo "Start this script with args: $0 <file_path> <search_string> <replace_string>"
    exit 1
fi    

FILEPATH=$1
SEARCH_STR=$2
REPLACE_STR=${3:-""}
LOGFILE="files.log"

# Check exists file
if [ ! -f $FILEPATH ]; then
    echo "File: $1 not found"
    exit 1
fi

curr_dir="$(basename $(pwd))/$FILEPATH"

# Basic check of input params
if [ -z $2 ]; then
    echo "Argument2(<search_string>) is empty: $2"
    exit 1
fi

hash_before=($(sha256sum "$FILEPATH"))

# Replace procedure
sed -i "s/$SEARCH_STR/$REPLACE_STR/g" "$FILEPATH"

hash_after=($(sha256sum "$FILEPATH"))

# Adding informatin in log
if [ $hash_before == $hash_after ]; then
    echo "No changes"
    exit 1
fi

# Fixing changes in LOGFILE
activity[0]=$curr_dir
activity[1]="-"
activity[2]=$(stat -c%s $FILEPATH)
activity[3]="-"
activity[4]=$(date +"%Y-%m-%d %H:%M")
activity[5]="-"
activity[6]=$hash_after
activity[7]="-"
activity[8]="sha256"

echo "${activity[@]}" >> $LOGFILE
