#ifndef SRC_INPUT_H_
#define SRC_INPUT_H_

int getDate(int* date);
int getChoice();
char* getPath();
char* s21_strcat(char* str1, char* str2);
char* getStr();

#endif  // SRC_INPUT_H_
