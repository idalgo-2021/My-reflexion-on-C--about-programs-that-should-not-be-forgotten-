#ifndef SRC_STATE_SORT_H_
#define SRC_STATE_SORT_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int getLen(FILE* ptr);

#endif  // SRC_STATE_SORT_H_
