#include <stdio.h>

#define SIZE 10

int readArray(int *array);

void heapSort(int *array, int n);
void heapify(int *array, int n, int i);
void swap(int *a, int *b);

void quickSort(int *array, int size);
int partition(int arr[], int low, int high);

void printArray(int *array);

int main() {
    int array[SIZE];
    if (readArray(array) != 0) {
        printf("n/a");
    } else {
        int array2[SIZE];
        for (int i = 0; i < SIZE; i++) {
            array2[i] = array[i];
        }

        // array
        heapSort(array, SIZE);
        printArray(array);

        printf("\n");

        // array2
        quickSort(array2, SIZE);
        printArray(array2);
    }
    return 0;
}

int readArray(int *a) {
    for (int *p = a; p - a < SIZE; p++) {
        if (scanf("%d", p) != 1) {
            return -1;
        }
    }

    if (getchar() != '\n') {
        return -1;
    }
    return 0;
}

void quickSort(int *array, int size) {
    if (size <= 1) return;  // Базовый случай: массив из одного или менее элемента уже отсортирован

    int pivot = array[size / 2];  // Опорный элемент

    // Разделение на подмассивы
    int i = 0, j = size - 1;
    while (i <= j) {
        while (array[i] < pivot) i++;
        while (array[j] > pivot) j--;
        if (i <= j) {
            swap(&array[i], &array[j]);
            i++;
            j--;
        }
    }

    // Рекурсивный вызов для подмассивов
    quickSort(array, j + 1);
    quickSort(array + i, size - i);
}

// Функция для разделения массива на две подмассива относительно опорного элемента
int partition(int *array, int low, int high) {
    int pivot = array[high];  // Опорный элемент
    int i = low - 1;          // Индекс меньшего элемента

    for (int j = low; j <= high - 1; j++) {
        // Если текущий элемент меньше или равен опорному
        if (array[j] <= pivot) {
            i++;  // Увеличиваем индекс меньшего элемента
            swap(&array[i], &array[j]);
        }
    }
    swap(&array[i + 1], &array[high]);
    return (i + 1);
}

// Пирамидальная сортировка
void heapSort(int *array, int n) {
    for (int i = n / 2 - 1; i >= 0; i--) heapify(array, n, i);

    for (int i = n - 1; i >= 0; i--) {
        swap(&array[0], &array[i]);
        heapify(array, i, 0);
    }
}

// Перестройка
void heapify(int *array, int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n && array[left] > array[largest]) largest = left;

    if (right < n && array[right] > array[largest]) largest = right;

    if (largest != i) {
        swap(&array[i], &array[largest]);
        heapify(array, n, largest);
    }
}

// Функция для обмена двух элементов массива
void swap(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void printArray(int *array) {
    int i;
    for (i = 0; i < SIZE; i++) {
        printf("%d ", array[i]);
    }
}