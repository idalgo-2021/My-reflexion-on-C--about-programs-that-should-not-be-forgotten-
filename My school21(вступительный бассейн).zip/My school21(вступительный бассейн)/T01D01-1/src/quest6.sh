chmod +x *.sh
cd ai_help
bash keygen.sh
rm key/file*
bash unifier.sh
