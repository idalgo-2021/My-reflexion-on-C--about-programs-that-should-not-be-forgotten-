chmod +x *.sh
mv door_management_fi door_management_files
cd door_management_files
mkdir door_configuration
mkdir door_logs
mkdir door_map
cd ..
cd door_management_files
mv *.conf door_configuration
mv *.log door_logs
mv door_map_1.1 door_map
cd ..
./ai_door_management_module.sh


