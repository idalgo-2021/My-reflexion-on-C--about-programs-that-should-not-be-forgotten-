﻿ps -u
kill -9 PID
