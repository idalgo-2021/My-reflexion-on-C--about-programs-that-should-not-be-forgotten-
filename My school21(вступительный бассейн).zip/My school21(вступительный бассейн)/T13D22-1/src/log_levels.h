#ifndef LOG_LEVELS
#define LOG_LEVELS

enum log_level { DEBUG, TRACE, INFO, WARNING, ERROR };

#endif
