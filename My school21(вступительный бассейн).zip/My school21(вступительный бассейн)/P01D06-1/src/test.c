#include <stdio.h>

int main() {
    // Определяем массив чисел
    int numbers[] = {10, 20, 30, 40, 50};
    int total = 0;
    int length = sizeof(numbers) / sizeof(numbers[0]);  // Определяем длину массива

    // Считаем сумму всех элементов массива
    for (int i = 0; i < length; ++i) {
        total += numbers[i];
    }

    // Вычисляем среднее арифметическое
    float average = (float)total / length;

    // Выводим результат
    printf("Среднее арифметическое: %.2f\n", average);

    return 0;
}
