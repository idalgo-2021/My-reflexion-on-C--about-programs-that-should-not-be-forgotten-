

#include <math.h>
#include <stdio.h>
// #define _USE_MATH_DEFINES
#define M_PI 3.14159265358979323846

double versniera(double x);
double lemniskata(double x);
double hiperbola(double x);

int main() {
    for (int i = 0; i <= 41; i++) {
        double t = -M_PI + 2 * M_PI / 41 * i;

        printf("%.7f|%.7f|", t, versniera(t));

        double lemn = lemniskata(t);
        if (lemn == 1) {
            printf("-|");
        } else {
            printf("%.7f|", lemn);
        }

        if (t == 0) {
            printf("-");
        } else {
            printf("%.7f", hiperbola(t));
        }

        if (i != 42) {
            printf("\n");
        }
    }
    return 0;
}

double versniera(double x) { return 1 / (1 + x * x); }

double lemniskata(double x) {
    if (sqrt(1 + 4 * x * x) - x * x - 1 <= 0) {
        return 1;
    }

    return sqrt(sqrt(1 + 4 * x * x) - x * x - 1);
}

double hiperbola(double x) {
    if (x == 0) {
        return 0;
    }
    return 1 / (x * x);
}
