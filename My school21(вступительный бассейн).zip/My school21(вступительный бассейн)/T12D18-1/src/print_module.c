#include "print_module.h"

#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

int print_char(char ch) { return putchar(ch); }

void print_log(int (*print)(char), char* message) {
    int i;

    // Печатаем префикс "[LOG]"
    for (i = 0; Log_prefix[i] != '\0'; i++) {
        print(Log_prefix[i]);
    }
    print(' ');

    // Получаем текущее время
    time_t t;
    struct tm* local;
    char str[128] = "";
    t = time(NULL);
    local = localtime(&t);
    strftime(str, 128, "%H:%M:%S", local);

    // Печатаем текущее время
    for (i = 0; str[i] != '\0'; i++) {
        print(str[i]);
    }
    print(' ');

    // Печатаем сообщение
    for (i = 0; message[i] != '\0'; i++) {
        print(message[i]);
    }
}

void print_docs(short mask, int documents_count, ...) {
    va_list ptr;
    va_start(ptr, documents_count);
    int ct = 0;
    while (mask > 0) {
        if (ct == documents_count) break;
        ct++;
        char* str = va_arg(ptr, char*);
        if ((mask % 2) == 1) {
            printf("%d.%-15s:", ct, str);
            printf("available\n");
        } else {
            printf("%d.%-15s:", ct, str);
            printf("unavailable\n");
        }
        mask /= 2;
    }
    va_end(ptr);
}