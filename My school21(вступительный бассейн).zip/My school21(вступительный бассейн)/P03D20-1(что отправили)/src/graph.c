#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "parser.h"
#include "rpn.h"

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#define WIDTH 80
#define HEIGHT 25

void plotGraph(const char *expression);

int main() {
    char expression[MAX_EXPR_LEN];

    // Prompt the user for an expression
    printf("Enter the expression to plot: ");
    if (fgets(expression, sizeof(expression), stdin) == NULL) {
        fprintf(stderr, "Error reading input.\n");
        return 1;
    }

    // Remove newline character if present
    expression[strcspn(expression, "\n")] = 0;

    plotGraph(expression);
    return 0;
}

void plotGraph(const char *expression) {
    // (void)system("clear");
    printf("\033[2J\033[H");
    printf("Expression: %s\n", expression);

    Token tokens[MAX_EXPR_LEN];
    Token rpn_tokens[MAX_EXPR_LEN];

    tokenize(expression, tokens);
    shuntingYard(tokens, rpn_tokens);

    char graph[HEIGHT][WIDTH];
    memset(graph, '.', sizeof(graph));

    // Calculate and plot each point on the graph
    for (int col = 0; col < WIDTH; ++col) {
        double x = 4.0 * M_PI * col / (WIDTH - 1);
        double y = evaluateRPN(rpn_tokens, x);

        int row = HEIGHT / 2 + (int)(y * (HEIGHT / 2));

        if (row >= 0 && row < HEIGHT) {
            graph[row][col] = '*';
        }
    }

    // Print the graph
    for (int row = 0; row < HEIGHT; ++row) {
        for (int col = 0; col < WIDTH; ++col) {
            printf("%c", graph[row][col]);
        }
        printf("\n");
    }
}
