#ifndef RPN_H
#define RPN_H

#include "parser.h"

double evaluateRPN(Token *rpn_tokens, double x);

#endif  // RPN_H
