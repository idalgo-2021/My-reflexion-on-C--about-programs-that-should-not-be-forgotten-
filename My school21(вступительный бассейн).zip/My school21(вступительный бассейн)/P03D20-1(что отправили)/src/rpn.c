#include "rpn.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

double evaluateRPN(Token *rpn_tokens, double x) {
    double stack[MAX_EXPR_LEN];
    int top = -1;

    for (int i = 0; rpn_tokens[i].type != END; ++i) {
        if (rpn_tokens[i].type == NUMBER) {
            stack[++top] = atof(rpn_tokens[i].value);
        } else if (rpn_tokens[i].type == VARIABLE) {
            stack[++top] = x;
        } else if (rpn_tokens[i].type == OPERATOR) {
            double op2 = stack[top--];
            double op1 = stack[top--];
            double result = 0.0;

            switch (rpn_tokens[i].value[0]) {
                case '+':
                    result = op1 + op2;
                    break;
                case '-':
                    result = op1 - op2;
                    break;
                case '*':
                    result = op1 * op2;
                    break;
                case '/':
                    result = op1 / op2;
                    break;
            }
            stack[++top] = result;
        } else if (rpn_tokens[i].type == FUNCTION) {
            double op = stack[top--];
            double result = 0.0;

            if (strcmp(rpn_tokens[i].value, "sin") == 0) {
                result = sin(op);
            } else if (strcmp(rpn_tokens[i].value, "cos") == 0) {
                result = cos(op);
            } else if (strcmp(rpn_tokens[i].value, "tan") == 0) {
                result = tan(op);
            } else if (strcmp(rpn_tokens[i].value, "ctg") == 0) {
                result = 1.0 / tan(op);
            } else if (strcmp(rpn_tokens[i].value, "sqrt") == 0) {
                result = sqrt(op);
            } else if (strcmp(rpn_tokens[i].value, "ln") == 0) {
                result = log(op);
            }
            stack[++top] = result;
        }
    }

    return stack[top];
}
