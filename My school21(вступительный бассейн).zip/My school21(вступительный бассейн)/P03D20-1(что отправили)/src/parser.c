#include "parser.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Utility function to check if a character is an operator
int isOperator(char c) { return c == '+' || c == '-' || c == '*' || c == '/'; }

// Utility function to check if a character is part of a function name
int isFunction(const char *str) {
    return strcmp(str, "sin") == 0 || strcmp(str, "cos") == 0 || strcmp(str, "tan") == 0 ||
           strcmp(str, "ctg") == 0 || strcmp(str, "sqrt") == 0 || strcmp(str, "ln") == 0;
}

// Tokenize input expression
void tokenize(const char *expr, Token *tokens) {
    int i = 0;
    int j = 0;

    while (expr[i] != '\0') {
        if (isdigit(expr[i]) || expr[i] == '.') {
            // Handle numbers
            int start = i;
            while (isdigit(expr[i]) || expr[i] == '.') i++;
            strncpy(tokens[j].value, &expr[start], i - start);
            tokens[j].value[i - start] = '\0';
            tokens[j].type = NUMBER;
            j++;
        } else if (isalpha(expr[i])) {
            // Handle functions and variables
            int start = i;
            while (isalpha(expr[i])) i++;
            strncpy(tokens[j].value, &expr[start], i - start);
            tokens[j].value[i - start] = '\0';
            if (isFunction(tokens[j].value)) {
                tokens[j].type = FUNCTION;
            } else {
                tokens[j].type = VARIABLE;
            }
            j++;
        } else if (isOperator(expr[i]) || expr[i] == '(' || expr[i] == ')') {
            // Handle operators and parentheses
            tokens[j].value[0] = expr[i];
            tokens[j].value[1] = '\0';
            tokens[j].type = isOperator(expr[i]) ? OPERATOR : (expr[i] == '(' ? LEFT_PAREN : RIGHT_PAREN);
            i++;
            j++;
        } else {
            // Ignore any other characters (e.g., spaces)
            i++;
        }
    }

    // Mark the end of the token list
    tokens[j].type = END;
}

// Implement Shunting Yard algorithm
void shuntingYard(Token *tokens, Token *output) {
    Token stack[MAX_EXPR_LEN];
    int top = -1;
    int j = 0;

    for (int i = 0; tokens[i].type != END; i++) {
        if (tokens[i].type == NUMBER || tokens[i].type == VARIABLE) {
            output[j++] = tokens[i];
        } else if (tokens[i].type == FUNCTION) {
            stack[++top] = tokens[i];
        } else if (tokens[i].type == OPERATOR) {
            while (top >= 0 && stack[top].type == OPERATOR) {
                output[j++] = stack[top--];
            }
            stack[++top] = tokens[i];
        } else if (tokens[i].type == LEFT_PAREN) {
            stack[++top] = tokens[i];
        } else if (tokens[i].type == RIGHT_PAREN) {
            while (top >= 0 && stack[top].type != LEFT_PAREN) {
                output[j++] = stack[top--];
            }
            top--;  // Pop the left parenthesis
            if (top >= 0 && stack[top].type == FUNCTION) {
                output[j++] = stack[top--];
            }
        }
    }

    while (top >= 0) {
        output[j++] = stack[top--];
    }

    // Mark the end of the output list
    output[j].type = END;
}
