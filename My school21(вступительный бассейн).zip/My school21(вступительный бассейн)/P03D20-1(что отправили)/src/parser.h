#ifndef PARSER_H
#define PARSER_H

#define MAX_EXPR_LEN 100

typedef enum { OPERATOR, FUNCTION, VARIABLE, NUMBER, LEFT_PAREN, RIGHT_PAREN, END } TokenType;

typedef struct {
    TokenType type;
    char value[MAX_EXPR_LEN];
} Token;

void tokenize(const char *expr, Token *tokens);
void shuntingYard(Token *tokens, Token *output);

#endif  // PARSER_H
