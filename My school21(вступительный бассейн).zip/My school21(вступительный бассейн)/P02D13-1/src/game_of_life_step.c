#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#define X 80
#define Y 25

void fill_rand(char map[][X]);
void show(char map[][X]);
void step(char map[][X]);
void copy(char src[][X], char dest[][X]);
int get_y(int i);
int get_x(int j);

int main() {
    system("clear");

    char map[Y][X];
    fill_rand(map);

    while (1) {
        show(map);
        step(map);
        usleep(100000);  // 100000 мк.с
        system("clear");
    }

    return 0;
}

void fill_rand(char map[][X]) {
    srand(time(NULL));
    for (int i = 0; i < Y; ++i) {
        for (int j = 0; j < X; ++j) {
            // if (rand() % 10 == 0) {  // 10%; 70%:(rand() % 10 < 7)
            if (rand() % 10 < 8) {
                map[i][j] = 1;
            } else {
                map[i][j] = 0;
            }
        }
    }
}

void show(char map[][X]) {
    for (int i = 0; i < Y; ++i) {
        for (int j = 0; j < X; ++j) {
            if (map[i][j] != 0) {
                printf("#");
            } else {
                printf("%c", ' ');
            }
        }
        printf("\n");
    }
}

void step(char map[][X]) {
    char prev[Y][X];
    copy(map, prev);

    for (int i = 0; i < Y; ++i) {
        for (int j = 0; j < X; ++j) {
            int count_neib = 0;
            count_neib += prev[get_y(i - 1)][get_x(j - 1)];
            count_neib += prev[get_y(i - 1)][get_x(j)];
            count_neib += prev[get_y(i - 1)][get_x(j + 1)];

            count_neib += prev[get_y(i)][get_x(j - 1)];
            count_neib += prev[get_y(i)][get_x(j + 1)];

            count_neib += prev[get_y(i + 1)][get_x(j - 1)];
            count_neib += prev[get_y(i + 1)][get_x(j)];
            count_neib += prev[get_y(i + 1)][get_x(j + 1)];

            if (prev[i][j] == 0 && count_neib == 3) {
                map[i][j] = 1;
            } else if (prev[i][j] == 1 && (count_neib == 2 || count_neib == 3)) {
                map[i][j] = 1;
            } else {
                map[i][j] = 0;
            }
        }
    }
}

void copy(char src[][X], char dest[][X]) {
    for (int i = 0; i < Y; ++i) {
        for (int j = 0; j < X; ++j) {
            dest[i][j] = src[i][j];
        }
    }
}

int get_y(int i) { return (Y + i) % Y; }

int get_x(int j) { return (X + j) % X; }