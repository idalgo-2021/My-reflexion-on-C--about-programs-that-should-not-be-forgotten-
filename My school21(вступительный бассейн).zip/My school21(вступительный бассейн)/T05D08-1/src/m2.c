#include <stdio.h>
#include <stdlib.h>

int main(void) {
    //////////////////////
    // char* arr = malloc(10);
    // int* ptr = malloc(sizeof(int));
    // short* ptr_shor = malloc(7 * sizeof(short));

    // free(arr);
    // free(ptr);
    // free(ptr_shor);

    /////////////////////
    size_t capacity = 10;
    size_t length = 0;

    return 0;
}