/*
    Search module for the desired value from data array.

    Returned value must be:
        - "even"
        - ">= mean"
        - "<= mean + 3 * sqrt(variance)"
        - "!= 0"

        OR

        0
*/
#include <math.h>
#include <stdio.h>
#define NMAX 30

int input(int *a, int *n);
void output(int *a, int n);
double mean(int *a, int n);
double variance(int *a, int n);

int main() {
    int n, data[NMAX];
    if (input(data, &n)) {
        printf("n/a");
        return 1;
    } else {
        output(data, n);
    }
    return 0;
}

int input(int *a, int *n) {
    int err = 0;
    if (scanf("%d", n) != 1 || *n <= 0 || *n > NMAX)
        err = 1;
    else {
        for (int *p = a; p - a < *n; p++) {
            if (scanf("%d", p) != 1) {
                err = 1;
                break;
            }
        }

        char ch = getchar();
        if (ch != '\n' && ch != EOF) {
            err = 1;
        }
    }
    return err;
}

double mean(int *a, int n) {
    // Мат.ожидание - ср.арифметическое
    double sum = 0;
    for (int i = 0; i < n; i++) {
        sum = sum + a[i];
    }

    return sum / n;
}

double variance(int *a, int n) {
    // Дисперсия - квадрат ср.кв.отклонения
    double mean_val = mean(a, n);
    double sum_squares = 0;

    for (int i = 0; i < n; i++) {
        sum_squares += (a[i] - mean_val) * (a[i] - mean_val);
    }
    return sum_squares / n;
}

void output(int *a, int n) {
    int res = 0;
    double mean_val = mean(a, n);
    double sigma3_val = sqrt(variance(a, n)) * 3.0;

    for (int i = 0; i < n; i++) {
        if (a[i] % 2 == 0 && a[i] >= mean_val && a[i] <= mean_val + sigma3_val && a[i] != 0) {
            res = a[i];
            break;
        }
    }
    printf("%d", res);
}