#include <stdio.h>
#define NMAX 5

int input(int *a, int *n);
void output(int *a, int n);
int max(int *a, int n);
int min(int *a, int n);
double mean(int *a, int n);
double variance(int *a, int n);
void output_result(int max_v, int min_v, double mean_v, double variance_v);

int main() {
    int n, data[NMAX];
    if (input(data, &n)) {
        printf("n/a");
        return 1;
    } else {
        output(data, n);
        output_result(max(data, n), min(data, n), mean(data, n), variance(data, n));
    }
    return 0;
}

int input(int *a, int *n) {
    int err = 0;
    if (scanf("%d", n) != 1 || *n <= 0 || *n > NMAX)
        err = 1;
    else {
        for (int *p = a; p - a < *n; p++) {
            if (scanf("%d", p) != 1) {
                err = 1;
                break;
            }
        }

        char ch = getchar();
        if (ch != '\n' && ch != EOF) {
            err = 1;
        }
    }
    return err;
}

void output(int *a, int n) {
    for (int *p = a; p - a < n; p++) {
        printf("%d", *p);

        if (p - a + 1 < n) {
            printf(" ");
        }
    }
}

int max(int *a, int n) {
    int curr_max = a[0];
    for (int i = 0; i < n; i++) {
        if (a[i] > curr_max) {
            curr_max = a[i];
        }
    }
    return curr_max;
}

int min(int *a, int n) {
    int curr_min = a[0];
    for (int i = 0; i < n; i++) {
        if (a[i] < curr_min) {
            curr_min = a[i];
        }
    }

    return curr_min;
}

double mean(int *a, int n) {
    // Мат.ожидание - ср.арифметическое
    double sum = 0;
    for (int i = 0; i < n; i++) {
        sum = sum + a[i];
    }

    return sum / n;
}

double variance(int *a, int n) {
    // Дисперсия - квадрат ср.кв.отклонения
    double mean_val = mean(a, n);
    double sum_squares = 0;

    for (int i = 0; i < n; i++) {
        sum_squares += (a[i] - mean_val) * (a[i] - mean_val);
    }
    return sum_squares / n;
}

void output_result(int max_v, int min_v, double mean_v, double variance_v) {
    printf("%d %d %.6lf %.6lf", max_v, min_v, mean_v, variance_v);
}