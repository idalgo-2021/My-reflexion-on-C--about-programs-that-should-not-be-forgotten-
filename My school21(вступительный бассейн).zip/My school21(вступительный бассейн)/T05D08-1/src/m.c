#include <stdio.h>

input(int *arr, int size);

int main() {
    //////////////////////////////////

    // int a = 10;
    // int *gpt;

    // gpt = &a;
    // printf("gpt = %p, *gpt = %d, d = %d\n", gpt, *gpt, a);
    // *gpt = 100;
    // printf("gpt = %p, *gpt = %d, d = %d\n", gpt, *gpt, a);

    //////////////////////////////////

    // int arr[] = {4, 3, 2, 1, 5, 6, 7};

    // int a1 = *arr;
    // int a4 = *(arr + 3);

    // for (int i = 0; i < sizeof(arr) / sizeof(*arr); ++i) {
    //     printf("%d", *(arr + i));
    // }

    // printf("\n");

    // int *ptr = arr;
    // int x = ptr[2];

    //////////////////////////////////

    int size = 5;
    int my_arr[size];
    if (input(my_arr, size) != 0) {
        printf("n/a");
        return -1;
    }

    for (int i = 0; i < size; i++) {
        printf("%d\n", my_arr[i]);
    }

    return 0;
}

int input(int *arr, int size) {
    for (int i = 0; i < size; i++) {
        if (scanf("%d", &arr[i]) != 1) {
            return -1;
        }
    }
    return 0;
}
